import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-html-ctrl',
  templateUrl: './my-html-ctrl.component.html',
  styleUrls: ['./my-html-ctrl.component.css']
})
export class MyHtmlCtrlComponent implements OnInit {
  private rows = [
    [
      {
        label: "Text",
        type: "text"
      },
      {
        label: "Number",
        type: "number"
      }
    ],
    [
      {
        label: "Dropdown",
        type: "select",
        options: []
      },
      {
        label: "Date",
        type: "date"
      }
    ]
  ];
  
  constructor() {
   }

  ngOnInit() {
  }

}
