import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyHtmlCtrlComponent } from './my-html-ctrl.component';

describe('MyHtmlCtrlComponent', () => {
  let component: MyHtmlCtrlComponent;
  let fixture: ComponentFixture<MyHtmlCtrlComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyHtmlCtrlComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyHtmlCtrlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
