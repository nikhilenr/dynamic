import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { MyHtmlCtrlComponent } from './my-html-ctrl/my-html-ctrl.component';

@NgModule({
  declarations: [
    AppComponent,
    MyHtmlCtrlComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
